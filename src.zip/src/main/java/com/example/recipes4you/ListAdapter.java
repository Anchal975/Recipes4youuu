package com.example.recipes4you;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ListAdapter extends BaseAdapter {
    private ArrayList<Recipe> prodList;
    private LayoutInflater inflater;


    public ListAdapter(Context context, ArrayList<Recipe> prodList){
        this.prodList=prodList;
        inflater = LayoutInflater.from(context);

    }
    @Override
    public int getCount() {
        return prodList.size();
    }

    @Override
    public Object getItem(int i) {
        return prodList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder;
        if (view==null){
            view = inflater.inflate(R.layout.list_row,null);
            holder = new ViewHolder();
            holder.name=view.findViewById(R.id.txtName);
            holder.img=view.findViewById(R.id.img);

            view.setTag(holder);
        }
        else
            holder=(ViewHolder)view.getTag();
        holder.name.setText(prodList.get(i).getRecipeName());
        int imgID = view.getResources().getIdentifier(prodList.get(i).getRecipeImage(),"mipmap", inflater.getContext().getPackageName());
        holder.img.setImageResource(imgID);
        return view;
    }
    static class ViewHolder{
        private TextView name;
        private ImageView img;
    }
}


