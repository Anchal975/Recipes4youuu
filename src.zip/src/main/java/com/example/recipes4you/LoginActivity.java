package com.example.recipes4you;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.recipes4you.Users;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
    EditText user,pass;
    Button login;
    ArrayList<Users> memberList = new ArrayList<Users>();
    public static String memberName = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        fillData();

        user=findViewById(R.id.etUser);
        pass=findViewById(R.id.etPass);
        login=findViewById(R.id.btnLogin);

        login.setOnClickListener(this);
    }
    public void fillData(){
        memberList.add(new Users(1234,"Anchal","user1", "password1"));
        memberList.add(new Users(2345,"Amit","user2", "password2"));
        memberList.add(new Users(1234,"Suruthi","user3", "password3"));

    }

    @Override
    public void onClick(View view) {
        String verify = verifyLogin(user.getText().toString(),pass.getText().toString());
        if(verify.isEmpty())
            Toast.makeText(getApplicationContext(),"Invalid username or password",Toast.LENGTH_LONG).show();
        else{
            memberName=verify;
            //navigate to main activity
            Intent intent = new Intent(this,MainActivity.class);
            startActivity(intent);
        }


    }
    public String verifyLogin(String userName,String password){
        for (int i=0;i<memberList.size();i++)
            if(userName.equals(memberList.get(i).getUserName()))
                if(password.equals(memberList.get(i).getPassword()))
                    return memberList.get(i).getName();
        return null;
    }
}