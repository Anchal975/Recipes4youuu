package com.example.recipes4you;

public class Recipe {
    String category;
    String subCategory;
    String recipeName;
    String recipeDetails;
    String recipeImage;


    public Recipe(String category, String subCategory, String recipeName, String recipeDetails, String recipeImage) {
        this.category = category;
        this.subCategory = subCategory;
        this.recipeName = recipeName;
        this.recipeDetails = recipeDetails;
        this.recipeImage = recipeImage;
    }

    public String getCategory() {
        return category;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public String getRecipeName() {
        return recipeName;
    }

    public String getRecipeDetails() {
        return recipeDetails;
    }

    public String getRecipeImage() {
        return recipeImage;
    }
}
