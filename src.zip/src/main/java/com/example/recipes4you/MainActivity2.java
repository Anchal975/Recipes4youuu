package com.example.recipes4you;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    TextView titl,detail;
    ImageView img;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        titl=findViewById(R.id.txtTitle);
        img=findViewById(R.id.imgBIg);
        detail=findViewById(R.id.txtDetails);


        Intent intent2 = getIntent();
        String str = intent2.getStringExtra("tit");
        int id = intent2.getIntExtra("id",0);
        String deet=intent2.getStringExtra("deta");
        titl.setText(str);
        img.setImageResource(id);
        detail.setText(deet);



    }
}